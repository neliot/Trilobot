/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: controller.js                          *
 * Author: Dr. Evil!                              *
 * Date: 22/01/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Basic gesture based robot controller           *
 **************************************************/

let controllerButtons = [];
let controllerEnabled = true;
let controllerVisible = true;
let controllerStopped = true;

function controllerInitialise(){
    controllerButtons.push(new Button((width / 2 - (200 * scaling) / 2) / scaling, 10, 200, 150, color(0, 0, 0, 50), color(255, 0, 0, 50), 16, "FORWARD", color(128, 128, 128, 128), TRILOBOT_MOVE + "forward"));
    controllerButtons.push(new Button((width / 2 - (200 * scaling) / 2) / scaling, 320, 200, 150, color(0, 0, 0, 50), color(255, 0, 0, 50), 16, "BACKWARD", color(128, 128, 128, 128), TRILOBOT_MOVE + "backward"));
    controllerButtons.push(new Button(10, 165, 200, 150, color(0, 0, 0, 50), color(255, 0, 0, 50), 16, "LEFT", color(128, 128, 128, 128), TRILOBOT_MOVE + "move"+"/"+ leftL.value() +"/"+ leftR.value()));
    controllerButtons.push(new Button(430, 165, 200, 150, color(0, 0, 0, 50), color(255, 0, 0, 50), 16, "RIGHT", color(128, 128, 128, 128), TRILOBOT_MOVE + "move"+"/"+ rightL.value() +"/"+ rightR.value()));    
}

function updateControllerButtons() {
    controllerButtons[0].action = TRILOBOT_MOVE + "move"+"/"+ forwardL.value() +"/"+ forwardR.value();
    controllerButtons[1].action = TRILOBOT_MOVE + "move"+"/"+ backwardsL.value() +"/"+ backwardsR.value();
    controllerButtons[2].action = TRILOBOT_MOVE + "move"+"/"+ leftL.value() +"/"+ leftR.value();
    controllerButtons[3].action = TRILOBOT_MOVE + "move"+"/"+ rightL.value() +"/"+ rightR.value();
}

function displayController(posX, posY) {
    if (controlActiveCheckBox.checked()) {
        controllerEnabled = true;
    } else {
        controllerEnabled = false;
    }

    if (controlVisibleCheckBox.checked()) {
        controllerVisible = true;
    } else {
        controllerVisible = false;
    }

    for (let i = 0; i < controllerButtons.length; i++) {
        controllerButtons[i].display(posX, posY, controllerEnabled, controllerVisible);
    }

    let btnActive = false;
    for (let i = 0; i < controllerButtons.length; i++) {
        if (controllerButtons[i].mouseOver) {
            btnActive = true;
            controllerStopped = false;
        }
    }

    if (!btnActive & controllerStopped == false) {
        controllerStopped = true;
        loadJSON(TRILOBOT_MOVE + "stop");
    }
}



// class Controller {
//     constructor(ROBOT_ADDR) {
//         this.buttons = [];
//         TRILOBOT_MOVE = ROBOT_ADDR;
//         this.enabled = true;
//         this.visible = true;
//         this.stopped = true;
//         this.initialize();
//     }

//     initialize() {
//         this.buttons.push(new Button((width / 2 - (200 * scaling) / 2) / scaling, 10, 200, 150, color(0, 0, 0, 50), color(255, 0, 0, 50), 16, "FORWARD", color(128, 128, 128, 128), TRILOBOT_MOVE + "forward"));
//         this.buttons.push(new Button((width / 2 - (200 * scaling) / 2) / scaling, 320, 200, 150, color(0, 0, 0, 50), color(255, 0, 0, 50), 16, "BACKWARD", color(128, 128, 128, 128), TRILOBOT_MOVE + "backward"));
//         this.buttons.push(new Button(10, 165, 200, 150, color(0, 0, 0, 50), color(255, 0, 0, 50), 16, "LEFT", color(128, 128, 128, 128), TRILOBOT_MOVE + "left"));
//         this.buttons.push(new Button(430, 165, 200, 150, color(0, 0, 0, 50), color(255, 0, 0, 50), 16, "RIGHT", color(128, 128, 128, 128), TRILOBOT_MOVE + "right"));
//         //        this.buttons.push(new Button((width / 2 - (200*scaling) / 2)/scaling, 165, 200, 150, color(0, 0, 0, 50), color(255, 0, 0, 50), 16, "STOP", color(128, 128, 128,  128), TRILOBOT_MOVE + "stop"));
//     }

//     display(posX, posY) {
//         if (controlActiveCheckBox.checked()) {
//             this.enabled = true;
//         } else {
//             this.enabled = false;
//         }

//         if (controlVisibleCheckBox.checked()) {
//             this.visible = true;
//         } else {
//             this.visible = false;
//         }

//         for (let i = 0; i < this.buttons.length; i++) {
//             this.buttons[i].display(posX, posY, this.enabled, this.visible);
//         }

//         let btnActive = false;
//         for (let i = 0; i < this.buttons.length; i++) {
//             if (this.buttons[i].mouseOver) {
//                 btnActive = true;
//                 this.stopped = false;
//             }
//         }

//         if (!btnActive & this.stopped == false) {
//             this.stopped = true;
//             loadJSON(TRILOBOT_MOVE + "stop");
//         }
//     }
// }