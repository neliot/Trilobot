/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: trilobot.js                              *
 * Author: Dr. Evil!                              *
 * Date: 22/01/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Basic Trilobot                                 *
 **************************************************/
let trilobot = null;

function getTriData(data) {
    trilobot = data;
}

function getTrilobotData() {
    loadJSON(TRILOBOT_MOVE, getTriData);
}

function displayTrilobotData() {
    if (trilobot) {
        textAlign(LEFT, CENTER);
        fill(0, 120);
        strokeWeight(1);
        stroke(125)
        textSize(25);
        text("[" + trilobot.id + "] " + trilobot.name, 10, 25);
    }
}

