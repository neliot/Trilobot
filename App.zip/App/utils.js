/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: utils.js                              *
 * Author: Dr. Evil!                              *
 * Date: 07/02/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Canvas utility functions                       *
 **************************************************/
function windowResized() {
    centerCanvas();
}

function centerCanvas() {
    let x = (windowWidth - width) / 2;
    let y = (windowHeight - height) / 2;
    cnv.position(x, y);
}

function saveSnapshot() {
    saveCanvas("canvas.png");
}

