/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: bme.js                                 *
 * Author: Dr. Evil!                              *
 * Date: 22/01/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * BME Handler                                    *
 * Using a class was problematic due to           *
 * setInterval needing current object access      * 
 * so rolled back to procedural implementation    *
 **************************************************/

// GLOBAL strings to hold sensor data 

let temperature = null;
let pressure = null;
let humidity = null;

async function bme(ADDR) {
    let response = await fetch(ADDR + "temperature");
    let json = await response.json();
    temperature = json.data + " " + json.units;
    response = await fetch(ADDR + "pressure");
    json = await response.json();
    pressure = json.data + " " + json.units;
    response = await fetch(ADDR + "humidity");
    json = await response.json();
    humidity = json.data + " " + json.units;
}

function displayBME() {
    textAlign(LEFT, CENTER);
    fill(0, 120);
    stroke(255)
    strokeWeight(1);
    textSize(15);
    if (temperature) {
        text("TEMP: " + temperature, 450, (height - 50*scaling)/scaling);
    } else {
        text("TEMP: READ ERROR", 450, (height - 50*scaling)/scaling);
    }
    if (pressure) {
        text("PRES: " + pressure, 450, (height - 100*scaling)/scaling);
    } else {
        text("PRES: READ ERROR", 450, (height - 100*scaling)/scaling);
    }
    if (pressure) {
        text("HUMI: " + humidity, 450, (height - 75*scaling)/scaling);
    } else {
        text("HUMI: READ ERROR", 450, (height - 75*scaling)/scaling);
    }
}

function bmeRun(){
    bme(TRILOBOT_BME).catch(error => {
         console.error(error);
         temperature = null;
         pressure = null;
         humidity = null;
     });
}

setInterval(bmeRun, 2000);

