/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: hand.js                              *
 * Author: Dr. Evil!                              *
 * Date: 24/01/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Application Side Menu                          *
 **************************************************/

let redSelect;
let greenSelect;
let blueSelect;
let colourTitle;
let controlTitle;
let configurationTitle;
let leftRight = null;
let control = null;
let controlActiveCheckBox=null;
let controlVisibleCheckBox=null;
let forwardL=null;
let forwardR=null;
let backwardsL=null;
let backwardsR=null;
let leftL=null;
let leftR=null;
let rightL=null;
let rightR=null;

function menu() {
    configurationTitle = createElement('h1', 'Configuration');
    configurationTitle.position(30, 30);
    controlTitle = createElement('h3', 'Controller');
    controlTitle.position(75, 75);
    controlActiveCheckBox = createCheckbox(' Control Active', false);
    controlActiveCheckBox.position(52, 120);
    controlVisibleCheckBox = createCheckbox(' Control Visible', true);
    controlVisibleCheckBox.position(52, 140);
    handTitle = createElement('h3', 'Handedness');
    handTitle.position(70, 150);
    leftRight = createRadio();
    leftRight.position(70, 195);
    leftRight.option("Left");
    leftRight.option("Right");
    leftRight.selected("Right");
    handTitle = createElement('h3', 'Camera');
    handTitle.position(85, 205);
    webcamRobot = createRadio();
    webcamRobot.position(50, 250);
    webcamRobot.option("Webcam");
    webcamRobot.option("Robot");
    webcamRobot.selected("Webcam");
    colourTitle = createElement('h3', 'Colour');
    colourTitle.position(90, 258);
    colourTitle2 = createElement('h3', 'R');
    colourTitle2.position(65, 280);
    colourTitle3 = createElement('h3', 'G');
    colourTitle3.position(103, 280);
    colourTitle4 = createElement('h3', 'B');
    colourTitle4.position(165, 280);
    redSelect = createSelect();
    redSelect.position(53, 325);
    greenSelect = createSelect();
    greenSelect.position(103, 325);
    blueSelect = createSelect();
    blueSelect.position(153, 325);
    for (let i = 0; i <= (255/15); i++) {
        redSelect.option(i*15);
        greenSelect.option(i*15);
        blueSelect.option(i*15);
    }
 // MOTOR CONTROL
    motorTitle = createElement('h3', 'Motors');
    motorTitle.position(95, 340);
    forwardL = createSelect();
    forwardL.position(80, 390);
    forwardR = createSelect();
    forwardR.position(130, 390);

    leftL = createSelect();
    leftL.position(20,420);
    leftR = createSelect();
    leftR.position(70, 420);
 
    rightL = createSelect();
    rightL.position(140,420);
    rightR = createSelect();
    rightR.position(190, 420);
 
    backwardsL = createSelect();
    backwardsL.position(80,450);
    backwardsR = createSelect();
    backwardsR.position(130, 450);

    let vals = [-1.0,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0];
    for (const val of vals){
        forwardL.option(val);
        forwardR.option(val);
        leftL.option(val);
        leftR.option(val);
        rightL.option(val);
        rightR.option(val);
        backwardsL.option(val);
        backwardsR.option(val);    
    }
    forwardL.selected(1.0);
    forwardR.selected(1.0);
    leftL.selected(-1.0);
    leftR.selected(1.0);
    rightL.selected(1.0);
    rightR.selected(-1.0);
    backwardsL.selected(-1.0);
    backwardsR.selected(-1.0);

    forwardL.changed(updateControllerButtons);
    forwardR.changed(updateControllerButtons);
    leftL.changed(updateControllerButtons);
    leftR.changed(updateControllerButtons);
    rightL.changed(updateControllerButtons);
    rightR.changed(updateControllerButtons);
    backwardsL.changed(updateControllerButtons);
    backwardsR.changed(updateControllerButtons);

    redSelect.changed(changeLights);
    greenSelect.changed(changeLights);
    blueSelect.changed(changeLights);
    leftRight.changed(leftRightChanged);

    let instruct0 = createElement('h2', 'Keyboard');
    instruct0.position(75, 470);
    let instruct1 = createElement('h3', '"s" - Snapshot');
    instruct1.position(60, 510);
    let instruct2 = createElement('h3', '"f" - Fullscreen');
    instruct2.position(57, 540);
}

function leftRightChanged(){
//    operator.which = leftRight.value();
    whichHand = leftRight.value();
}