/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: hand.js                              *
 * Author: Dr. Evil!                              *
 * Date: 24/01/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Basic hand detection                           *
 **************************************************/
let handPose;
let hands = [];
let handX = 0;
let handY = 0;
let whichHand = "Right";
let leftHand = null;
let rightHand = null;

function handPreLoad() {
    handPose = ml5.handPose({ flipped: true });
}

function gotHands(results) {
    hands = results;
}

function startHands() {
    handPose.detectStart(video, gotHands);
    rightHand = loadImage('pointerR.png');
    console.log(rightHand);
    leftHand = loadImage('pointerL.png');
}

function displayHand() {
    if (hands.length > 0) {
        for (let hand of hands) {
            if (hand.confidence > 0.2 && hand.handedness == whichHand) {
                handX = hand.middle_finger_mcp.x;
                handY = hand.middle_finger_mcp.y;
                if (handX > 0 & handY > 0) {
                    //                    imageMode(CORNER);
                    if (whichHand == "Right") {
                        image(rightHand, handX, handY, rightHand.width / 4, rightHand.height / 4);
                    } else {
                        image(leftHand, handX - (leftHand.width / 4), handY, leftHand.width / 4, rightHand.height / 4);
                    }
                }
            }
        }
    } else {
        handX = 0;
        handY = 0;
    }
}