/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: sketch.js                              *
 * Author: Dr. Evil!                              *
 * Date: 22/01/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Basic gesture based robot control              *
 **************************************************/
let video;
let camera;
let cnv;

let operator = null;
let TRILOBOT_MOVE = "http://" + IP + ":5001/";
let CAMERA_URL = "http://" + IP + ":8080/video_feed";
let TRILOBOT_BME = "http://" + IP + ":5000/";
let TRILOBOT_LIGHTS = "http://" + IP + ":5001/colour/";

function preload() {
  handPreLoad();
}

function windowResized() {
  centerCanvas();
}

function centerCanvas() {
  let x = (windowWidth - width) / 2;
  let y = (windowHeight - height) / 2;
  cnv.position(x, y);
}

function setup() {
  cnv = createCanvas(640 * scaling, 480 * scaling);
  centerCanvas();
  video = createCapture(VIDEO, { flipped: true });
  video.hide();
  camera = createImg(CAMERA_URL, "Trilobot Feed");
  camera.hide();
  startHands();
  menu();
  changeLights();
  getTrilobotData();
  controllerInitialise();
}

function draw() {
  scale(scaling);
  displayVideo();
  displayController(handX, handY);
  displayHand();
  displayFeedInfo(webcamRobot.value());
  displayTrilobotData();
  displayBME();
}
