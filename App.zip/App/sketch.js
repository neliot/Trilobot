/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: sketch.js                              *
 * Author: Dr. Evil!                              *
 * Date: 22/01/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Basic gesture based robot control              *
 **************************************************/

let video;
let camera;
let cnv;

let TRILOBOT_MOVE = "http://" + IP + ":5001/";
let CAMERA_URL = "http://" + IP + ":8080/video_feed";
let TRILOBOT_BME = "http://" + IP + ":5000/";
let TRILOBOT_LIGHTS = "http://" + IP + ":5001/colour/";


function preload() {
  handPreLoad();
}

function keyPressed() {
  if (key === 's') {
    saveSnapshot();
  }
  if (key == 'f') {
    if (fullscreen()) {
      fullscreen(false);
    } else {
      fullscreen(true);
    }
  }
}

function setup() {
  cnv = createCanvas(640 * scaling, 480 * scaling);
  centerCanvas();
  video = createCapture(VIDEO, { flipped: true });
  video.hide();
  camera = createImg(CAMERA_URL, "Trilobot Feed", "anonymous");
  camera.hide();
  startHands();
  menu();
  changeLights();
  getTrilobotData();
  controllerInitialise();
}

function draw() {
  scale(scaling);
  displayVideo();
  displayController(handX, handY);
  displayFeedInfo(webcamRobot.value());
  displayTrilobotData();
  displayBME();
  displayHand();
}
