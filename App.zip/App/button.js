/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: button.js                              *
 * Author: Dr. Evil!                              *
 * Date: 22/01/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Basic controller button                        *
 **************************************************/
class Button {
    constructor(x, y, w, h, backCol, highlight, textSize, text, textCol, btnAction) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.backCol = backCol;
        this.textCol = textCol;
        this.highlight = highlight;
        this.text = text;
        this.textSize = textSize;
        this.action = btnAction;
        this.mouseOver = false;
    }

    display(mX, mY, enabled, visible) {
        if (mX > this.x && mX < (this.x + this.w)
            && mY > this.y && mY < (this.y + this.h)) {
            fill(this.highlight);
            if (this.mouseOver == false & enabled) {
                loadJSON(this.action);
            }
            this.mouseOver = true;
        } else {
            fill(this.backCol);
            this.mouseOver = false;
        }
        if (visible) {
            noStroke();
            rect(this.x, this.y, this.w, this.h);
            textAlign(CENTER, CENTER);
            fill(this.textCol);
            textSize(this.textSize);
            text(this.text, this.x + (this.w / 2), this.y + (this.h / 2));
        }
    }
}