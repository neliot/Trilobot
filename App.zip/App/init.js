/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: init.js                                *
 * Author: Dr. Evil!                              *
 * Date: 06/02/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Initialisation parameters                                             *
 **************************************************/
// APPLICATION TITLE SETUP
const NAME = "Trilobot Challenge"
const APPVERSION = "0.9.1";

// GLOBAL string to hold IP address of Trilobot 
let IP = "192.168.8.239";

// GLOBAL scaling factor
// FOR HD use 1.5
// FOR UHD (4K) use 2.5
let scaling = 1.5;



