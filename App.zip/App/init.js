/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: init.js                                  *
 * Author: Dr. Evil!                              *
 * Date: 06/02/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Initialisation parameters                                             *
 **************************************************/

// GLOBAL strings to hold IP address of Trilobot 
let IP = "192.168.1.166";
// GLOBAL scaling factor
let scaling = 2;

