/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: sketch.js                              *
 * Author: Dr. Evil!                              *
 * Date: 05/02/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Basic video selector             *
 **************************************************/

function displayVideo() {
    if (webcamRobot.value() == "Webcam") {
        image(video, 0, 0, 640, 480);
    } else {
        if (camera) {
            image(camera, 0, 0, 640, 480);
        }
    }
}

function displayFeedInfo(which) {
    textAlign(LEFT, CENTER);
    fill(0, 120);
    strokeWeight(1);
    stroke(125)
    textSize(25);
    text(which, 530, 25);
}