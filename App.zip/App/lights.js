/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: trilobot.js                              *
 * Author: Dr. Evil!                              *
 * Date: 22/01/2025                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Basic Lights                                *
 **************************************************/

function changeLights() {
    let lights = redSelect.value() + "/" + greenSelect.value() + "/" + blueSelect.value();
    loadJSON(TRILOBOT_LIGHTS + lights);
}